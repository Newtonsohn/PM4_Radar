var searchData=
[
  ['testing_20firmware_0',['Testing Firmware',['../testing.html',1,'']]],
  ['testing_2edox_1',['testing.dox',['../testing_8dox.html',1,'']]],
  ['text_5fcolor_2',['text_color',['../struct_m_e_n_u__entry__t.html#aecbba4786b2fa7dd9667472c1b260132',1,'MENU_entry_t']]],
  ['tim2_5firqhandler_3',['TIM2_IRQHandler',['../measuring_8c.html#a38ad4725462bdc5e86c4ead4f04b9fc2',1,'measuring.c']]],
  ['tim_5fclock_4',['TIM_CLOCK',['../measuring_8c.html#a8f1900825debd6a99026eb55d9998131',1,'measuring.c']]],
  ['tim_5fprescale_5',['TIM_PRESCALE',['../measuring_8c.html#ad3224fe94be10ed1c61870bd1d22b86d',1,'measuring.c']]],
  ['tim_5ftop_6',['TIM_TOP',['../measuring_8c.html#a00237ed21338f907db7d88aeb54fecf2',1,'measuring.c']]],
  ['todo_20list_7',['Todo List',['../todo.html',1,'']]]
];
