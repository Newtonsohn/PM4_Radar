var searchData=
[
  ['line1_0',['line1',['../struct_m_e_n_u__entry__t.html#ae1acd6e390dd5194d11208034acb8d91',1,'MENU_entry_t']]],
  ['line2_1',['line2',['../struct_m_e_n_u__entry__t.html#a94cbcf18d647f9987b421714c2dc5147',1,'MENU_entry_t']]]
];
