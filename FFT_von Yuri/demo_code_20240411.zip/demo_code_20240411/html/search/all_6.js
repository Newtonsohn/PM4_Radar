var searchData=
[
  ['flipped_5flcd_0',['FLIPPED_LCD',['../main_8h.html#a2a80fd66666fdab43ddc82448cd8450c',1,'main.h']]]
];
