var searchData=
[
  ['text_5fcolor_0',['text_color',['../struct_m_e_n_u__entry__t.html#aecbba4786b2fa7dd9667472c1b260132',1,'MENU_entry_t']]]
];
