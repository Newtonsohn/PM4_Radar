var searchData=
[
  ['coding_20guidelines_0',['Coding Guidelines',['../coding_guidelines.html',1,'']]]
];
