/*
 * radar.h
 *
 *  Created on: Mar 30, 2025
 *      Author: Jurek_Volpez
 */

#ifndef SRC_RADAR_H_
#define SRC_RADAR_H_

	void init_radar(void);
	void init_gpio(void);
	void subsystem_test(void);

#endif /* SRC_RADAR_H_ */
