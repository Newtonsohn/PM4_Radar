var searchData=
[
  ['cable_20monitor_0',['Cable-Monitor',['../index.html',1,'']]],
  ['calc_2ec_1',['calc.c',['../calc_8c.html',1,'']]],
  ['calc_2eh_2',['calc.h',['../calc_8h.html',1,'']]],
  ['calc_5fdistance_3',['calc_distance',['../calc_8h.html#a73be5150190c801f1eca407238cb541e',1,'calc.h']]],
  ['calculate_5fangle_4',['calculate_angle',['../calc_8h.html#a57beaef35a66b6721474cbe2de82daff',1,'calculate_angle(float distance_left, float distance_right):&#160;calc.c'],['../calc_8c.html#a57beaef35a66b6721474cbe2de82daff',1,'calculate_angle(float distance_left, float distance_right):&#160;calc.c']]],
  ['calculate_5fcurrent_5',['calculate_current',['../calc_8h.html#aba0eae8e7760be4959124286b09d6431',1,'calculate_current(float rms):&#160;calc.c'],['../calc_8c.html#aba0eae8e7760be4959124286b09d6431',1,'calculate_current(float rms):&#160;calc.c']]],
  ['calculate_5fdistance_6',['calculate_distance',['../calc_8h.html#af854d26b7a2a599d5211415350ee9c06',1,'calculate_distance(float rms):&#160;calc.c'],['../calc_8c.html#af854d26b7a2a599d5211415350ee9c06',1,'calculate_distance(float rms):&#160;calc.c']]],
  ['calculate_5fmoving_5fmean_7',['calculate_moving_mean',['../calc_8h.html#acb33f773a4fb15515f56d22342077deb',1,'calculate_moving_mean(float new_value, int channel):&#160;calc.c'],['../calc_8c.html#acb33f773a4fb15515f56d22342077deb',1,'calculate_moving_mean(float new_value, int channel):&#160;calc.c']]],
  ['calculate_5frms_8',['calculate_rms',['../calc_8h.html#a24abf34eeef535d207350c81d913cd66',1,'calc.h']]],
  ['channel1_9',['channel1',['../main_8h.html#a30cd674902096d3c7b0649d472e6daca',1,'channel1:&#160;main.c'],['../main_8c.html#ab6a4ce07cdfcb4234ef1653f7b32f351',1,'channel1:&#160;main.c']]],
  ['channel2_10',['channel2',['../main_8h.html#a6439d66230330e72681bd07e75f001fc',1,'channel2:&#160;main.c'],['../main_8c.html#ab5f6b1da7807c52f19fdda36807782fe',1,'channel2:&#160;main.c']]],
  ['current_5ftime_11',['current_time',['../main_8h.html#ade0cb3ddf0ea3e243b785a56be5b5cca',1,'current_time:&#160;main.c'],['../main_8c.html#ade0cb3ddf0ea3e243b785a56be5b5cca',1,'current_time:&#160;main.c']]]
];
