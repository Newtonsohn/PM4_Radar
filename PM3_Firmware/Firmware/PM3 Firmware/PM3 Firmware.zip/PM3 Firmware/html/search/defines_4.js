var searchData=
[
  ['rms_5fwindow_5fsize_0',['RMS_WINDOW_SIZE',['../calc_8h.html#ad177d5cfbd61ae33424a8803a08ef9b2',1,'calc.h']]]
];
