var searchData=
[
  ['active_5fmenu_0',['active_menu',['../main_8c.html#afbafc996f30fb7c73f54aecc1e3c38b3',1,'main.c']]],
  ['adc_5fsample_5fcount_1',['ADC_sample_count',['../measuring_8c.html#a70e7c139b5911548b5eacdd74e471d5b',1,'measuring.c']]],
  ['adc_5fsamples_2',['ADC_samples',['../main_8h.html#ab157d7f58882d3990395a0eb3e7cb366',1,'ADC_samples:&#160;measuring.c'],['../measuring_8h.html#ab157d7f58882d3990395a0eb3e7cb366',1,'ADC_samples:&#160;measuring.c'],['../measuring_8c.html#ab7f88c24d5816d6d48d932fdb53caaf2',1,'ADC_samples:&#160;measuring.c']]],
  ['adc_5fvalue_3',['ADC_value',['../measuring_8h.html#a2a5f32bdea1d7c4e05f40d2654b8a6a4',1,'measuring.h']]],
  ['angle_4',['angle',['../measuring_8c.html#ab8ef1bf8a70cc07c6d55823c390a7e76',1,'measuring.c']]]
];
