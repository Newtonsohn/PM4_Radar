var searchData=
[
  ['rms_0',['rms',['../calc_8h.html#a286882c517d505c86b4bf35aa09ce32f',1,'rms(uint32_t *results):&#160;calc.c'],['../calc_8c.html#a286882c517d505c86b4bf35aa09ce32f',1,'rms(uint32_t *results):&#160;calc.c']]]
];
