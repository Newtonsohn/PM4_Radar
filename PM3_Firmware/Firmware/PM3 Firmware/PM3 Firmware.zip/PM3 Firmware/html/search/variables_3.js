var searchData=
[
  ['dac_5factive_0',['DAC_active',['../measuring_8h.html#a69a35c5e5ae036f9089962dbc385aa71',1,'DAC_active:&#160;measuring.c'],['../measuring_8c.html#a69a35c5e5ae036f9089962dbc385aa71',1,'DAC_active:&#160;measuring.c']]],
  ['dac_5fsample_1',['DAC_sample',['../measuring_8c.html#a8da5353c93f5798cf6c95956418a2210',1,'measuring.c']]],
  ['distance_2',['distance',['../measuring_8c.html#a06f14a9abd47b91465f895d5259cdc1b',1,'measuring.c']]]
];
