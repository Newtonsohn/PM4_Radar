var searchData=
[
  ['back_5fcolor_0',['back_color',['../struct_m_e_n_u__entry__t.html#a0fd107c268f85989486fd5e5aa6a538b',1,'MENU_entry_t']]],
  ['buffer_5fsize_1',['BUFFER_SIZE',['../calc_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'calc.h']]],
  ['bug_20list_2',['Bug List',['../bug.html',1,'']]]
];
