var searchData=
[
  ['channel1_0',['channel1',['../main_8h.html#a30cd674902096d3c7b0649d472e6daca',1,'channel1:&#160;main.c'],['../main_8c.html#ab6a4ce07cdfcb4234ef1653f7b32f351',1,'channel1:&#160;main.c']]],
  ['channel2_1',['channel2',['../main_8h.html#a6439d66230330e72681bd07e75f001fc',1,'channel2:&#160;main.c'],['../main_8c.html#ab5f6b1da7807c52f19fdda36807782fe',1,'channel2:&#160;main.c']]],
  ['current_5ftime_2',['current_time',['../main_8h.html#ade0cb3ddf0ea3e243b785a56be5b5cca',1,'current_time:&#160;main.c'],['../main_8c.html#ade0cb3ddf0ea3e243b785a56be5b5cca',1,'current_time:&#160;main.c']]]
];
