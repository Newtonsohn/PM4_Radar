var searchData=
[
  ['calc_5fdistance_0',['calc_distance',['../calc_8h.html#a73be5150190c801f1eca407238cb541e',1,'calc.h']]],
  ['calculate_5fangle_1',['calculate_angle',['../calc_8h.html#a57beaef35a66b6721474cbe2de82daff',1,'calculate_angle(float distance_left, float distance_right):&#160;calc.c'],['../calc_8c.html#a57beaef35a66b6721474cbe2de82daff',1,'calculate_angle(float distance_left, float distance_right):&#160;calc.c']]],
  ['calculate_5fcurrent_2',['calculate_current',['../calc_8h.html#aba0eae8e7760be4959124286b09d6431',1,'calculate_current(float rms):&#160;calc.c'],['../calc_8c.html#aba0eae8e7760be4959124286b09d6431',1,'calculate_current(float rms):&#160;calc.c']]],
  ['calculate_5fdistance_3',['calculate_distance',['../calc_8h.html#af854d26b7a2a599d5211415350ee9c06',1,'calculate_distance(float rms):&#160;calc.c'],['../calc_8c.html#af854d26b7a2a599d5211415350ee9c06',1,'calculate_distance(float rms):&#160;calc.c']]],
  ['calculate_5fmoving_5fmean_4',['calculate_moving_mean',['../calc_8h.html#acb33f773a4fb15515f56d22342077deb',1,'calculate_moving_mean(float new_value, int channel):&#160;calc.c'],['../calc_8c.html#acb33f773a4fb15515f56d22342077deb',1,'calculate_moving_mean(float new_value, int channel):&#160;calc.c']]],
  ['calculate_5frms_5',['calculate_rms',['../calc_8h.html#a24abf34eeef535d207350c81d913cd66',1,'calc.h']]]
];
