var searchData=
[
  ['filter_5fchannels_0',['filter_channels',['../calc_8h.html#a00ebe9f29203007db4274e18b31b1467',1,'calc.h']]],
  ['firmware_1',['Testing Firmware',['../testing.html',1,'']]]
];
