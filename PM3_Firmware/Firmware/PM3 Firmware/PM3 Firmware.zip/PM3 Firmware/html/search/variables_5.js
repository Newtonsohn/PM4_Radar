var searchData=
[
  ['inactivity_5ftimer_0',['inactivity_timer',['../main_8c.html#ae1ad5f8cca3a720c5c3ddec0078512ee',1,'main.c']]]
];
